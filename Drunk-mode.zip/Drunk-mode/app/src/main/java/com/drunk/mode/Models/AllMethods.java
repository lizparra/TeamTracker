package com.drunk.mode.Models;

public class AllMethods {
    public static String name = "";
}
