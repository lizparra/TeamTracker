package com.drunk.mode.Models;

/**
 * Created by Haroon on 12/23/2017.
 */

public class CircleJoin
{
    public String circlememberid;

    public CircleJoin(String circlememberid)
    {
        this.circlememberid = circlememberid;

    }

    public CircleJoin()
    {}

    public String getCirclememberid() {
        return circlememberid;
    }
}
