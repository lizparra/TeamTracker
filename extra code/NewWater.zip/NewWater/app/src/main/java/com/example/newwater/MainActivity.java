package com.example.newwater;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;

import static android.app.AlarmManager.INTERVAL_HOUR;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initiate the switch
        final Switch waterSwitch = findViewById(R.id.WaterSwitch);

        // when the switch is switched on, set hourly reminders
        waterSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                waterSwitch.setChecked(true);

                Intent myIntent = new Intent(MainActivity.this, MainActivity.class);

                PendingIntent pendingIntent = PendingIntent.getService(MainActivity.this, 0, myIntent, 0);

                AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                if (null != alarmManager) {
                    alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, INTERVAL_HOUR, INTERVAL_HOUR, pendingIntent);
                }

            }
        });

    }
}
