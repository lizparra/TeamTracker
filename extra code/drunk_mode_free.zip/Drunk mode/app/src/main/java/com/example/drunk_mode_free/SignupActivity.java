package com.example.drunk_mode_free;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class SignupActivity extends AppCompatActivity {

    EditText Name, Phone, Password, Email;
    TextView tvLogin;
    Button SubmitBtn;
    ProgressBar progressBar;

    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;

    DatabaseReference dbref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_signup);

        SetupViews();       //initialize textfields and button

        mAuth = FirebaseAuth.getInstance();

        SubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = Name.getText().toString().trim();
                final String phone = Phone.getText().toString().trim();
                final String email = Email.getText().toString().trim();
                final String password = Password.getText().toString().trim();

                if(email.isEmpty()){
                    Email.setError("Provide an Email");
                    Email.requestFocus();
                }
                else if(password.isEmpty()){
                    Password.setError("Provide a Password");
                    Password.requestFocus();
                }
                else if(email.isEmpty() && password.isEmpty()){
                    Toast.makeText(SignupActivity.this, "Required Fields Are Empty", Toast.LENGTH_SHORT).show();
                }
                else if(!(email.isEmpty() && password.isEmpty())){
                    progressBar.setVisibility(View.VISIBLE);
                    mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){

                                User user = new User(name, phone, password, email);

                                FirebaseDatabase.getInstance().getReference("USERS")
                                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        progressBar.setVisibility(View.GONE);
                                        if(task.isSuccessful()){
                                            Toast.makeText(SignupActivity.this, "Successfully added user", Toast.LENGTH_LONG).show();
                                        }
                                        else{
                                            //error
                                        }
                                    }
                                });
                                startActivity(new Intent(SignupActivity.this, UserHomepageActivity.class));
                            }
                            else{
                                Toast.makeText(SignupActivity.this, "Error Signing Up", Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                }
            }
        });
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() != null){                          //if a user is signed in
                    startActivity(new Intent(SignupActivity.this, UserHomepageActivity.class));
                }
            }
        };

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogInPortal();
            }
        });
    }

    @Override
    protected void onStart(){
        super.onStart();

        if(mAuth.getCurrentUser() != null){
            //login
        }
    }

    private void SetupViews(){
        Name = findViewById(R.id.fullname);
        Phone = findViewById(R.id.phonenumber);
        Password = findViewById(R.id.password);
        Email = findViewById(R.id.email);
        SubmitBtn = findViewById(R.id.loginBtn);
        tvLogin = findViewById(R.id.tvLogin);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
    }

    private void addUser(String uniqueID, String name, String phone, String email, String password){
         User user = new User(name, phone, password, email);

         dbref.child(uniqueID).setValue(user);
         Toast.makeText(this, "User Signed Up", Toast.LENGTH_LONG).show();
    }

    private void LogInPortal(){                       //get forwarded to login page
        Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    private void SignIn(){
        String email = Email.getText().toString();
        String password = Password.getText().toString();

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(!task.isSuccessful()){
                    Toast.makeText(SignupActivity.this, "Error Signing In", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(SignupActivity.this, "Successfully Signed In", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(SignupActivity.this, UserHomepageActivity.class));
                }
            }
        });
    }

    private Boolean validate(){
        Boolean result = false;

        String name = Name.getText().toString();
        String phone = Phone.getText().toString();
        String password = Password.getText().toString();
        String email = Email.getText().toString();

        if(email.isEmpty() || password.isEmpty() || name.isEmpty()){
            if(email.isEmpty()) {
                Email.setError("Enter Email");
                Email.requestFocus();
            }
            if(password.isEmpty()){
                Password.setError("Enter Password");
                Password.requestFocus();
            }
            if(name.isEmpty()){
                Name.setError("Enter Password");
                Name.requestFocus();
            }
        }
        else{
            result = true;
        }

        return result;
    }
}
