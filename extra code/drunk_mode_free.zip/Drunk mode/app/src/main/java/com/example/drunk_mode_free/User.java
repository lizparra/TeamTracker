package com.example.drunk_mode_free;

public class User {


    public String uniqueID, Name, Phone, Password, Email;

    public User() {

    }

    public User(String Name, String Phone, String Password, String Email){
        this.Name = Name;
        this.Phone = Phone;
        this.Password = Password;
        this.Email = Email;

    }

    public String getUniqueID() {
        return uniqueID;
    }

    public void setUniqueID(String uniqueID) {
        this.uniqueID = uniqueID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
