package com.swe.drunkmode.Notifications;

public class MyResponse {

    public int success;
}
